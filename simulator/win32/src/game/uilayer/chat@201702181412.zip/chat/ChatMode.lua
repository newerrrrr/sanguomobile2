local ChatMode = {}
setmetatable(ChatMode,{__index = _G})
setfenv(1, ChatMode)

local userCallback

local ChatType = {
  World = "world_chat",
  Guild = "guild_chat",
  BlackName = "black_name",
  Battle = "battle_fight",
}

function getChatTypeEnum()
  return ChatType 
end 

local function onSendSuccess(target, msgid, data)
  if userCallback then 
    userCallback(target, msgid, data) 
    userCallback = nil 
  end 
end 

function regChatSendCallback()
  g_sgNet.registMsgCallback(g_Consts.NetMsg.ChatSendRsp, ChatMode, onSendSuccess) 
end 

function unRegChatSendCallback()
  g_sgNet.unregistMsgCallback(g_Consts.NetMsg.ChatSendRsp, ChatMode)
end 

function sendChatMsg(type, data, callback)
  userCallback = callback 
  g_sgNet.sendMessage(g_Consts.NetMsg.ChatSendReq, {Type=type, Data = data})
end 

--分享战斗报告/侦查报告/历史战报到联盟聊天
function shareMailToGuild(mailData, isHistroy, callback) 
  local str = ""
  local mailType 

  if nil == mailData then return end 

  if isHistroy then --历史战报 
    if mailData.detail.win then 
      str = g_tr("chat_history_battle_win", {name1 = mailData.detail.player1.nick, name2 = mailData.detail.player2.nick}) 
    else 
      str = g_tr("chat_history_battle_lost", {name1 = mailData.detail.player1.nick, name2 = mailData.detail.player2.nick}) 
    end 
    mailType = 4

  else --我的战斗报告和侦查报告
    local MailHelper = require("game.uilayer.mail.MailHelper"):instance() 
    local MailType = MailHelper:getMailTypeEnum() 
    local SpyType = MailHelper:getSpyTypeEnum() 
    local BattleSubType = MailHelper:getBattleSubTypeEnum()  
       
    if mailData.type == MailType.Detect then --侦查报告
      mailType = 3 
      local target = ""
      if mailData.data.type == SpyType.Normal then --侦查主城
        if mailData.data.target_player.guild_short_name and mailData.data.target_player.guild_short_name ~= "" then 
          target = "(".. mailData.data.target_player.guild_short_name ..")"
        end 
        target = target .. mailData.data.target_player.nick
      elseif mailData.data.type == SpyType.Castle then --侦查联盟 
        if mailData.data.guild_short_name and mailData.data.guild_short_name ~= "" then 
          target = target .. "("..mailData.data.guild_short_name..")"
        end 
        local element = g_data.map_element[mailData.data.map_element_id]
        if element then 
          target = target ..g_tr(element.name)
        end 
      elseif mailData.data.type == SpyType.Resource or mailData.data.type == SpyType.JuDian or mailData.data.type == SpyType.KingFight then --侦查资源点/据点
        local item = g_data.map_element[mailData.data.map_element_id] 
        if item then 
          target = g_tr(item.name)
        end 
      end 
      str = g_tr("chat_spy_info", {name = target})

    else --战斗报告
      mailType = 4 
      if mailData.data.type == BattleSubType.Normal then --攻打主城 
        local playerName = ""
        if mailData.data.player2.guild_short_name ~= "" then 
          playerName = "("..mailData.data.player2.guild_short_name .. ")"
        end 
        playerName = playerName .. mailData.data.player2.nick 
        if MailHelper:isKindOfAtk(mailData.type) then 
          if mailData.data.win then 
            str = g_tr("chat_battle_city_win", {name = playerName})
          else 
            str = g_tr("chat_battle_city_lost", {name = playerName})
          end 
        else 
          if mailData.data.win then 
            str = g_tr("chat_battle_city_win2", {name = playerName})
          else 
            str = g_tr("chat_battle_city_lost2", {name = playerName})
          end           
        end 

      elseif mailData.data.type == BattleSubType.Resource then --资源战
        local playerName = ""
        if mailData.data.player2.guild_short_name ~= "" then 
          playerName = "("..mailData.data.player2.guild_short_name .. ")"
        end 
        playerName = playerName .. mailData.data.player2.nick         
        if MailHelper:isKindOfAtk(mailData.type) then 
          if mailData.data.win then 
            str = g_tr("chat_battle_res_atk_win", {name = playerName})
          else 
            str = g_tr("chat_battle_res_atk_lost", {name = playerName})
          end 
        else 
          if mailData.data.win then 
            str = g_tr("chat_battle_res_def_win", {name = playerName})
          else 
            str = g_tr("chat_battle_res_def_lost", {name = playerName})
          end 
        end 

      elseif mailData.data.type == BattleSubType.Castle then --攻打联盟堡垒 
        if mailData.data.win then 
          str = g_tr("chat_battle_castle_win", {name = mailData.data.player2.nick or ""}) 
        else 
          str = g_tr("chat_battle_castle_lost", {name = mailData.data.player2.nick or ""}) 
        end         
      end 
    end 
  end 

  local function shareMailResult(msgid, data)
    print("shareMailResult")
    g_airBox.show(g_tr("chat_share_success"))
    if callback then 
      callback()
    end 
  end 

  if nil == mailType then return end 

  local myId = g_PlayerMode.GetData().id 
  local data = {player_id=myId, content=str, userData={mail_type=mailType, mail_id=mailData.id, histroy=isHistroy}}
  sendChatMsg("guild_chat", data, shareMailResult)
end 

function isInBlackList(palyerId)
  local blackData = g_chatData.GetData(ChatType.BlackName, false)
  if nil == blackData then 
    return false 
  end 

  for k, v in pairs(blackData) do 
    if v.black_player_id == palyerId then 
      return true 
    end 
  end 
 
  return false 
end 

function isInBlackListEx(blackList, palyerId)
  for k, v in pairs(blackList) do 
    if v.black_player_id == palyerId then 
      return true 
    end 
  end 
  return false 
end 

function getSysInfo(itemData)
  local isSysInfo = false 
  local desc = ""
  if itemData.data and itemData.data.type and itemData.data.type ~= 5 then --历史战报不属于系统信息
    isSysInfo = true 

    if itemData.data.type == 1 then --击杀boss 
      local npc = g_data.npc[tonumber(itemData.data.boss_npc_id)]
      if npc then 
        local bossName = g_tr(npc.monster_name)
       desc = g_tr(g_data.title_notice[8].desc, {playername=itemData.nick, bossname = bossName}) 
      end 

    elseif itemData.data.type == 2 then --招募武将
      local general = g_data.general[itemData.data.general_id*100+1] 
      local genName = "" 
      local descId = 7 --金色
      if general then 
        genName = g_tr(general.general_name)
        descId = general.general_quality == 5 and 7 or 11 
      end 
      desc = g_tr(g_data.title_notice[descId].desc, {playername = itemData.nick, generalname = genName})

    elseif itemData.data.type == 3 then --装备进阶 
      local equId = tonumber(itemData.data.equipment_id)
      local equipment = g_data.equipment[equId] 
      if equipment then 
        local equipName = g_tr(equipment.equip_name)
        local descId = equipment.quality_id == 5 and 10 or 9 
        desc = g_tr(g_data.title_notice[descId].desc, {playername=itemData.nick, equipmentname=equipName, startstar=equipment.star_level-1,endstar=equipment.star_level})  
      end 

    elseif itemData.data.type == 4 then --皇陵探宝 
      local drop = g_data.drop[tonumber(itemData.data.drop)]
      if drop then 
        local dropItem = drop.drop_data[1]
        local item = require("game.uilayer.common.DropItemView"):create(dropItem[1], dropItem[2], dropItem[3])
        if item then 
          desc = g_tr("chat_draw_treasure", {player = itemData.nick, num = itemData.data.times, item = item:getName()})
          desc = desc .. "x"..dropItem[3]
        end     
      end 

    elseif itemData.data.type == 6 then --联盟聊天: 新加入联盟玩家
      desc = g_tr("chat_new_member", {name = itemData.data.nick})

    elseif itemData.data.type == 7 then --联盟聊天: 官职升降 
      local rankName = itemData.data.to_rank_name
      if rankName == "" then 
        rankName = g_tr("allianceRankName"..itemData.data.to_rank) 
      end 
      if itemData.data.step == "up" then 
        desc = g_tr("chat_be_promoted", {name = itemData.data.member_nick, leader = itemData.data.admin_nick, rank = rankName})
      else 
        desc = g_tr("chat_be_degrated", {name = itemData.data.member_nick, leader = itemData.data.admin_nick, rank = rankName})
      end 

    elseif itemData.data.type == 8 then --联盟聊天: 被剔除联盟
      desc = g_tr("chat_be_removed", {name = itemData.data.member_nick, leader = itemData.data.admin_nick}) 

    elseif itemData.data.type == 9 then --联盟聊天: 自动退出联盟
      desc = g_tr("chat_quite", {name = itemData.data.member_nick}) 

    elseif itemData.data.type == 10 then --联盟商店买东西 
      local itemName = ""
      if itemData.data.itemId and g_data.item[itemData.data.itemId] then 
        itemName = g_tr(g_data.item[itemData.data.itemId].item_name)
      end 
      desc = g_tr("chat_buy_from_guild_shop", {player = itemData.data.nick, num = itemData.data.itemNum, item = itemName})

    elseif itemData.data.type == 11 then --聚宝盆
      local itemName = ""
      if itemData.data.item_id and g_data.item[itemData.data.item_id] then 
        itemName = g_tr(g_data.item[itemData.data.item_id].item_name)
      end 
      desc = g_tr(g_data.title_notice[15].desc, {playername = itemData.nick, itemname = itemName})

    elseif itemData.data.type == 12 then --化神
      local itemName = ""
      if itemData.data.general_id then 
        local general = g_data.general[itemData.data.general_id*100+1] 
        if general then 
          desc = g_tr(g_data.title_notice[16].desc, {playername = itemData.nick, generalname = g_tr(general.general_name)})  
        end 
      end 
      
    elseif itemData.data.type == 13 then --弹劾
      desc = g_tr("impeachTips", {name1 = itemData.data.from_nick, name2 = itemData.data.to_nick})
    end 
  end 

  return isSysInfo, desc 
end 

function getRecordDirectory()
  local _fileUtils = cc.FileUtils:getInstance()
  local storagePath = _fileUtils:getWritablePath().."VoiceRecord/"
  if not _fileUtils:isDirectoryExist(storagePath) then 
    _fileUtils:createDirectory(storagePath) 
  end 

  return storagePath 
end 

regChatSendCallback()

return ChatMode
